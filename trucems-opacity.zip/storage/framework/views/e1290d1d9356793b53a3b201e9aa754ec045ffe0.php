<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="<?php echo e(url('favicon.png')); ?>" type="image/x-icon">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(url('css/app.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>

</head>
<body>
    <div class="max-w-5xl mx-auto bg-gray-200 rounded min-h-[100vh] relative">
        <?php echo $__env->yieldContent('content'); ?>
        <div class="absolute bottom-0 w-full flex justify-end px-5 py-2">
            <span class="text-gray-800">&copy; 2022 Developed by PT. Trusur Unggul Teknusa</span> 
        </div>
    </div>
   
<script src="<?php echo e(url("js/jquery.min.js")); ?>"></script>
<?php echo $__env->yieldContent('js'); ?>
</body>
</html><?php /**PATH /home/ir001/www/trucems/resources/views/layouts/theme.blade.php ENDPATH**/ ?>