
<?php $__env->startSection('title', 'Configuration'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(url('js/kioskboard/kioskboard-2.2.0.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('sweetalert2/sweetalert2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="px-6 py-3 bg-gray-200 rounded">
        <div class="bg-gray-300 h-[83vh] rounded-tl-3xl rounded-br-3xl">
            <div class="flex justify-between">
                <a href="<?php echo e(url('/')); ?>" role="button" class="rounded-tl-3xl rounded-br-3xl px-5 py-4 bg-red-500 text-white">
                    Back
                </a>
                <div class="py-4">
                    <span class="bg-indigo-700 py-4 px-3 text-white">
                    </span>
                </div>
           </div>
            <div class="p-4">
                <table class="table w-full text-left rounded">
                    <thead class="text-center">
                        <th>Action</th>
                        <th>Sensor</th>
                        <th>Code</th>
                        <th>Reading Formula</th>
                        <th>Write Address ID</th>
                    </thead>
                    <tbody id="tbody-logs" class="text-center">
                        <?php $__currentLoopData = $sensors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="w-[9rem]">
                                    <a href="<?php echo e(url("sensor/edit/{$sensor->id}")); ?>" class="inline-block p-2 bg-indigo-500 text-white">Edit</a>
                                </td>
                                <td><?php echo $sensor->name; ?></td>
                                <td><?php echo e($sensor->code); ?></td>
                                <td><?php echo e($sensor->read_formula); ?></td>
                                <td><?php echo e($sensor->write_address); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\trucems-opacity\resources\views/sensors/index.blade.php ENDPATH**/ ?>