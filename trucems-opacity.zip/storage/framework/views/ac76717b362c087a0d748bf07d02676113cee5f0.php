
<?php $__env->startSection('title', 'Configuration'); ?>
<?php $__env->startSection('content'); ?>
    <div class="px-6 py-3 bg-gray-200 rounded">
        <div class="h-[88vh] bg-gray-300 rounded-tl-3xl rounded-br-3xl">
            <div class="flex justify-between">
                <a href="<?php echo e(url('/')); ?>" role="button" class="rounded-tl-3xl rounded-br-3xl px-5 py-4 bg-red-500 text-white">
                    Back
                </a>
                <span class="bg-indigo-700 px-5 py-4"></span>
           </div>
            <div id="error-msg">
            </div>
            <div class="flex justify-center mt-[3vh]">
                    <div>
                        <?php for($i = 0; $i <= 7; $i++): ?>
                        <div class="flex items-start justify-start w-full mb-3">
                            <label for="toggle<?php echo e($i); ?>" class="flex items-center cursor-pointer">
                                <div class="relative">
                                    <?php
                                        $d = "d$i";
                                    ?>
                                    <input type="checkbox" id="toggle<?php echo e($i); ?>" class="sr-only checkbox-switch"
                                        data-id="<?php echo e($i); ?>" <?php echo e($plc->$d == 1 ? 'checked' : ''); ?>>
                                    <div class="block bg-gray-600 w-[5vw] h-10 rounded-full"></div>
                                    <div class="dot absolute left-1 top-1 bg-white w-8 h-8 rounded-full transition"></div>
                                </div>
                                <div class="ml-3 text-gray-700 font-medium text-2xl ">
                                    <?php switch($i):
                                        case (0): ?>
                                            Sampling
                                            <?php break; ?>
                                        <?php case (1): ?>
                                            Back Blowing
                                            <?php break; ?>
                                        <?php case (2): ?>
                                            Run
                                            <?php break; ?>
                                        <?php case (3): ?>
                                            Peristaltic Pump
                                            <?php break; ?>
                                        <?php case (4): ?>
                                            System Failure
                                            <?php break; ?>
                                        <?php case (5): ?>
                                            Back Blowing Inside The Probe
                                            <?php break; ?>
                                        <?php case (6): ?>
                                            Back Blowing Outside The Probe
                                            <?php break; ?>
                                        <?php case (7): ?>
                                            All Process Calibration
                                            <?php break; ?>
                                        <?php default: ?>
                                            
                                    <?php endswitch; ?>
                                </div>
                            </label>
            
                        </div>
                    <?php endfor; ?>
                </div>
           </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $('.checkbox-switch').change(function() {
                $.ajax({
                    url: `<?php echo e(url('api/relay')); ?>`,
                    type: 'PATCH',
                    dataType: 'json',
                    data: {
                        relay_d: $(this).data('id')
                    },
                    success: function(data) {}
                })
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\trucems\resources\views/relay/index.blade.php ENDPATH**/ ?>